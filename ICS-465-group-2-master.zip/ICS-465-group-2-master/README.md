# ICS-465-group-2
Week 2 assignment 
